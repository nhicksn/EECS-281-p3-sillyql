// Project Identifier: C0F4DFE8B340D81183C208F70F9D2D797908754D

#include "TableEntry.h"
#include "silly.h"
#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
    std::ios::sync_with_stdio(false);
    cin >> std::boolalpha;
    cout << std::boolalpha;
    Silly s(argc, argv);
    s.readInput();
}